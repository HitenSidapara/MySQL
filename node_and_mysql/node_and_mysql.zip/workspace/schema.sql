create table users(
    email varchar(255) primary key,
    created_at timestamp default now()
);


insert into users(email)
values('abc@gmail.com'),
      ('omkhunt@gmail.com');
      
      
insert into users(email,created_at)
values('abc@gmail.com','2018-08-21T21:31:19.242Z');



SELECT CASE 
         WHEN email LIKE '%@gmail.com' THEN 'gmail' 
         WHEN email LIKE '%@yahoo.com' THEN 'yahoo' 
         WHEN email LIKE '%@hotmail.com' THEN 'hotmail' 
         ELSE 'other' 
       end      AS provider, 
       Count(*) AS total_users 
FROM   users 
GROUP  BY provider 
ORDER  BY total_users DESC;

