    //  some note
    //   Root User: hitensidapara
    //   Database Name: c9



// include the faker and mysql module

var faker = require('faker');
var mysql = require('mysql');


//create a connection

var connection=mysql.createConnection({
    host : 'localhost',
    user : 'hitensidapara',
    database : 'join_us'
});


//run query

// var q= "SELECT CURTIME() as time ,CURDATE() as date,NOW() as now";

// var q = "select count(*) as total from users";

// connection.query(q,function(error,results,fields){
//   if (error) throw error;
//   console.log(results[0].total);
// });


//inserting data static


// var i = "insert into users(email) values('akshaypadasala123@gmail.com')";

// connection.query(i,function(error,results,fields){
//   if (error) throw error;
//   console.log(results);
// });


// inserting data dynamic

// var person = {
//     email : faker.internet.email(),
//     created_at : faker.date.past() //automatically convert into the database formate that is the power of node sql module
// };

//console.log(person);

// var end_result = connection.query('INSERT INTO users SET ?',person,function(error,results){
//   if (error) throw error;
//   console.log(results);
// });

//console.log(end_result.sql);



var data=[];
for(var i=1;i<=500;i++){
data.push([
// data.push() =>used to the push data at the last in array
faker.internet.email(),
faker.date.past()
]);
}
// console.log(data);

var q = 'INSERT INTO users(email,created_at) VALUES ?';

connection.query(q,[data],function(error,results){
    if (error) throw error;
    console.log(results);
});

connection.end();        //close the connection

