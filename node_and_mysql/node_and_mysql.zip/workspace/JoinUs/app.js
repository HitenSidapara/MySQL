// include the express module that is used to the web development 

var express = require('express');
var mysql = require('mysql');
var bodyParser = require('body-parser');   //it is used to extract the html form element data
var app = express();

app.set("view engine","ejs");
app.use(bodyParser.urlencoded({extended:true}));
app.use(express.static(__dirname+"/public"));      //include our public folder

var connection=mysql.createConnection({
    host : 'localhost',
    user : 'hitensidapara',
    database : 'join_us'
});

app.get("/",function(req,res){
   
   var q = "SELECT COUNT(*) AS count FROM users";
   connection.query(q,function(error,results){
       if (error) throw error;
       var count=results[0].count;
    //   res.send("wwe have "+count+" users in our database");
    
        res.render("home",{data : count});                       //here data object pass to the home.ejs template and use in home.ejs
   })  
   console.log("USER REQUEST OUR HOME PAGE");
});


// create a post ruote

 app.post("/register",function(req,res){
    console.log("Register Request comes! : " + req.body.email);
    var person = {
    email : req.body.email
    };

     connection.query('INSERT INTO users SET ?',person,function(error,results){
    if (error) throw error;
    console.log(results);
    res.redirect("/");
    });
});

// listen method is used to listen the port number

app.listen(8080,function(){
    console.log("server running on port 8080");
})








