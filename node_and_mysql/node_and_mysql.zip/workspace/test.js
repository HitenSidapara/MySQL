// inclue the faker module

// faker module is used to generate the fake data.


var faker=require('faker');
function generateAddress(){
    console.log(faker.address.streetAddress());
    console.log(faker.address.state());
    console.log(faker.address.city());
}

generateAddress();


for(let i=0;i<=500;i++)
{
 console.log("Hello World!");
}